#include <linux/init.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/fs.h>
#include <linux/uaccess.h>

#define DEVICE_NAME "mychardev"
#define MAX_DATA_LEN 50

static int device_open(struct inode*, struct file*);
static int device_release(struct inode*, struct file*);
static ssize_t device_read(struct file*, char*, size_t, loff_t*);
static ssize_t device_write(struct file*, const char*, size_t, loff_t*);

static struct file_operations fops = {
	.open = device_open,
	.read = device_read,
	.write = device_write,
	.release = device_release,
};

static int major;
uint8_t data_buffer[MAX_DATA_LEN];

static int device_open(struct inode *inodep, struct file *filep)
{
	printk(KERN_ALERT "Character device opened\n");
	return 0;
}

static ssize_t device_read(struct file *filep, char *buffer, size_t len, loff_t *offset)
{
	int errors = 0;
	
	size_t message_len =strlen(data_buffer); 

	// printk(KERN_ALERT "Message length %zd\n", message_len);
	errors = copy_to_user(buffer, data_buffer, message_len);

	return errors == 0 ? message_len : -EFAULT;	
}

static ssize_t device_write(struct file *filep, const char *buffer, size_t len, loff_t *offset)
{
	int errors = copy_from_user(data_buffer, buffer, len);

	if (len > MAX_DATA_LEN)
		len = MAX_DATA_LEN;

	if (errors==0)
	{
		printk(KERN_ALERT "Copied %zd bytes from the user\n", len);
	}
	else
	{
		printk(KERN_ALERT "Can't copy %zd bytes from the user\n", len);
		return -EFAULT;
	};
	
	printk(KERN_ALERT "Data from the user: %s\n", data_buffer);
	return len;
}

static int device_release(struct inode *inodep, struct file *filep)
{
	printk(KERN_ALERT "Character device closed\n");
	return 0;
}

static int __init character_device_module_init(void)
{
	major = register_chrdev(0, DEVICE_NAME, &fops);
	
	if (major < 0) 
	{
		printk(KERN_ALERT "Character device module load failed\n");
		return major;
	}

	printk(KERN_ALERT "Character device module with major: %d\n has been loaded", major);
	return 0;
}

static void __exit character_device_module_exit(void)
{
	unregister_chrdev(major, DEVICE_NAME);
	printk(KERN_ALERT "Character device module has been unloaded\n");
}

module_init(character_device_module_init);
module_exit(character_device_module_exit);
