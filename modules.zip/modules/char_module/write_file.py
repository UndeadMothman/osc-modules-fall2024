f=open('/dev/mychardev', 'w')
f.write("Hello World")
f.close()
