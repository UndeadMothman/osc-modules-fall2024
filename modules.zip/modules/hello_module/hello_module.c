#include <linux/module.h>
#include <linux/init.h>

/* Meta information */
MODULE_LICENSE("Dual BSD/GPL");
MODULE_AUTHOR("Yikang Shi");
MODULE_DESCRIPTION("A Hello World LKM");

/**
 * @brief This function is called, when the module is loaded into the kernel.
 */
static int __init ModuleInit(void)
{
	printk(KERN_ALERT "Hello, kernel!\n");
	return 0;
}

/**
 * @brief This function is called, when the module is removed from the kernel.
 */
static void __exit ModuleExit(void)
{
	printk(KERN_ALERT "Goodbye, kernel!\n");
}

module_init(ModuleInit);
module_exit(ModuleExit);
