#include <linux/module.h>
#include <linux/init.h>
#include <linux/fs.h>

/* Meta information */
MODULE_LICENSE("Dual BSD/GPL");
MODULE_AUTHOR("Yikang Shi");
MODULE_DESCRIPTION("Registers a device number and implement some callback function");

/**
 * @brief THis function is called, when the device file is opened
 */
static int driver_open(struct inode *device_file, struct file *instance)
{
	printk(KERN_ALERT "device_number - open was called!\n");
	return 0;
}

static int driver_close(struct inode *device_file, struct file *instance)
{
	printk(KERN_ALERT "device_number - close was called!\n");
	return 0;
}

static struct file_operations fops =
{
	.owner=THIS_MODULE,
	.open=driver_open,
	.release=driver_close,
};

#define MAJOR_DEVICE_NUMBER 90


/**
 * @brief This function is called, when the module is loaded into the kernel.
 */
static int __init ModuleInit(void)
{
	int retval;
	printk(KERN_ALERT "Hello, kernel!\n");
	
	/* register device number. */
	retval = register_chrdev(MAJOR_DEVICE_NUMBER, "my_device_number", &fops);
	
	if (retval==0)
	{
		printk(KERN_ALERT "device_number - registered device number Major: %d, Minor: %d\n", 			MAJOR_DEVICE_NUMBER, 0);
	}
	else if (retval>0)
	{
		printk(KERN_ALERT "device_number - registered device number Major: %d, Minor: %d\n", 			retval>>20, retval&0xfffff);
	}
	else
	{
		printk(KERN_ALERT "Could not register device number!\n");
		return -1;
	}

	return 0;
}

/**
 * @brief This function is called, when the module is removed from the kernel.
 */
static void __exit ModuleExit(void)
{
	printk(KERN_ALERT "Goodbye, kernel!\n");
	
	unregister_chrdev(MAJOR_DEVICE_NUMBER, "my_device_number");

}

module_init(ModuleInit);
module_exit(ModuleExit);
